<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Survey extends CI_Controller {

    public function create() {
        $this->load->view('header');
        $this->load->view('left');
        $this->load->view('create');
        $this->load->view('footer');
    }

    public function view() {
        $this->load->view('header');
        $this->load->view('left');
        $this->load->view('view');
        $this->load->view('footer');
    }

    public function history() {
        $this->load->view('header');
        $this->load->view('left');
        $this->load->view('history');
        $this->load->view('footer');
    }
    
    
}

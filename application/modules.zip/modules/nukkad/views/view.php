<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Registration From                            
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                    </li>
                    <li class="active">
                        <i class="fa fa-file"></i> Registration
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <form role="form">
                <div class="col-lg-6">   
                    <div class="form-group">
                        <label>Please select user type according to your job</label>
                        <div class="radio">
                            <label>
                                <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked>Register for Nukkad
                            </label>
                        </div>
                        <div class="radio">
                            <label>
                                <input type="radio" name="optionsRadios" id="optionsRadios2" value="option2">Register for Survey
                            </label>
                        </div>                                
                    </div>
                    <div class="form-group">
                        <label>First Name</label>
                        <input class="form-control">
                        <p class="help-block">Example block-level help text here.</p>
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input class="form-control">
                        <p class="help-block">Example block-level help text here.</p>
                    </div>
                    <div class="form-group">
                        <label>User Id</label>
                        <input class="form-control">
                        <p class="help-block">User Id should be unique.</p>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input class="form-control" placeholder="Enter text">
                    </div>
                    <div class="form-group">
                        <label>Re-type password</label>
                        <input class="form-control" placeholder="Enter text">
                        <p class="help-block">Password & Re-type password should be.</p>
                    </div>
                    <div class="form-group">
                        <label>Mobile No</label>
                        <input class="form-control" placeholder="Enter text">
                        <p class="help-block">Please enter your 10 digit mobile number</p>
                    </div>
                    <div class="form-group">
                        <label>Email-Id</label>
                        <input class="form-control" placeholder="Enter text">
                        <p class="help-block">Please enter your email-id</p>
                    </div>
                    <button type="reset" class="btn btn-default">Resend OTP</button>                        
                </div>
                <div class="col-lg-6">
                    <h2>OTP (One Time Password)</h2>
                    <div class="form-group">
                        <label>OTP</label>
                        <input class="form-control">
                        <p class="help-block">Contact to Admin for OTP</p>
                    </div>
                    <button type="reset" class="btn btn-default">Submit</button> 
                    <button type="reset" class="btn btn-default">Cancel</button> 
                </div>
            </form>    
        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->

</div>
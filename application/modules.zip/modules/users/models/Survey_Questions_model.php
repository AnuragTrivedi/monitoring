<?php

class Survey_Questions_model  extends CI_Model {

    public $id;
    public $state_id;
    public $constituency_id;
    public $question;
    public $created_by;
    public $created_at;

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
    }

    public function add_new_survey_question($data) { 
        $this->state_id = $this->input->post('state_id');
        $this->constituency_id = $this->input->post('constituency_id');
        $this->question = $this->input->post('question');
        $this->created_by = $data['created_by'];
        $this->modified_by = $data['modified_by'];
        $this->status='0';
        $this->db->insert('survey_questions', $this);
        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }    
    public function questionsdata($per_page, $offset, $search_keywords_array, $search_orderby_string) {
        $sdata = array();
        $this->db->select('*')->from('survey_questions');
        if (count($search_keywords_array) > 0)
            $this->db->like($search_keywords_array);

        if (!empty($search_orderby_string))
            $this->db->order_by($search_orderby_string);

        $this->db->limit($per_page, $offset);
        $query_result = $this->db->get();
        echo $this->db->last_query(); // shows last executed query       
        if ($query_result->num_rows() > 0) {
            foreach ($query_result->result_array() as $row) {
                $sdata[] = array('id' => $row['id'],'state_id' => $row['state_id'], 'constituency_id' => $row['constituency_id'], 'question' => $row['question']);
            }
        }
        return $sdata;
    }

    public function searchterm_handler($field, $searchterm) {
        if ($searchterm) {
            $this->session->set_userdata($field, $searchterm);
            return $searchterm;
        } elseif ($this->session->userdata($field)) {
            $searchterm = $this->session->userdata($field);
            return $searchterm;
        } else {
            $searchterm = "";
            return $searchterm;
        }
    }
    
    public function get_survey_questions($state_id,$constituency_id) {
        $condition = "state_id =" . "'" . $state_id . "' AND " . "constituency_id =" . "'" . $constituency_id . "' AND status=1";
        $this->db->select('id,question');
        $this->db->from('survey_questions');
        $this->db->where($condition);       
        $query = $this->db->get(); 
        $questions=array();
        if ($query->result()) {
            foreach ($query->result() as $question) {
                $questions[$question->id] = $question->question;
            }            
            return $questions;
        } else {
            return FALSE;
        }
    }   
}

?>
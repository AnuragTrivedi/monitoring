<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript">// <![CDATA[
    $(document).ready(function () {
        $('#state').change(function () { //any select change on the dropdown with id state trigger this code
            $("#constituency > option").remove(); //first of all clear select items
            var state_id = $('#state').val(); // here we are taking state id of the selected one.
            $.ajax({
                type: "POST",
                url: "<?php echo base_url() ?>users/get_constituencies/" + state_id, //here we are calling our user controller and get_cities method with the state_id

                success: function (constituencies) //we're calling the response json array 'cities'
                {
                    $.each(constituencies, function (id, constituency) //here we're doing a foeach loop round each city with id as the key and city as the value
                    {
                        var opt = $('<option />'); // here we're creating a new select option with for each city
                        opt.val(id);
                        opt.text(constituency);
                        $('#constituency').append(opt); //here we will append these new select options to a dropdown with the id 'cities'
                    });
                }

            });

        });
    });
    // ]]>
</script>
<div id="page-wrapper">
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Add new survey question                    
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="<?php echo base_url() ?>users/dashboard">Dashboard</a>
                    </li>
                    <li class="active">
                        <i class="fa fa-file"></i> Add new Constituency 
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-6">
                <?php echo validation_errors(); ?>
                <form method="POST" action="<?php echo base_url();?>users/add_question">
                    <div class="form-group">
                        <label>Select state</label>
                        <?php echo form_dropdown('state_id', $states, '#', 'id="state" class="form-control"'); ?>
                    </div>
                    <div class="form-group">
                        <label>Select Constituency</label>
                        <?php $constituencies['#'] = 'Please Select'; ?>
                        <?php echo form_dropdown('constituency_id', $constituencies, '#', 'id="constituency" class="form-control"'); ?>
                    </div>
                    <div class="form-group">
                        <label>Question</label>
                        <input type="text" name="question" id="question" class="form-control" placeholder="Enter text">
                        <p class="help-block">Please enter survey question & goto list to activiate it </p>
                    </div>                         
                    <input type="submit" class="btn btn-default" name="submit" value="Add new">
                    <button type="reset" class="btn btn-default">Cancel</button>
                </form>
            </div>           
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
</div>
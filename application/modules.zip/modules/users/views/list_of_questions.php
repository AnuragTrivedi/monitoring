<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript">// <![CDATA[
    $(document).ready(function () {
        $('#state').change(function () { //any select change on the dropdown with id state trigger this code
            $("#constituency > option").remove(); //first of all clear select items
            var state_id = $('#state').val(); // here we are taking state id of the selected one.
            $.ajax({
                type: "POST",
                url: "<?php echo base_url() ?>users/get_constituencies/" + state_id, //here we are calling our user controller and get_cities method with the state_id

                success: function (constituencies) //we're calling the response json array 'cities'
                {
                    $.each(constituencies, function (id, constituency) //here we're doing a foeach loop round each city with id as the key and city as the value
                    {
                        var opt = $('<option />'); // here we're creating a new select option with for each city
                        opt.val(id);
                        opt.text(constituency);
                        $('#constituency').append(opt); //here we will append these new select options to a dropdown with the id 'cities'
                    });
                }

            });

        });
    });
    // ]]>
</script>
<?php
$page_num = (int) $this->uri->segment(2);
if ($page_num == 0)
    $page_num = 1;
$order_seg = $this->uri->segment(5, "asc");
if ($order_seg == "asc")
    $order = "desc";
else
    $order = "asc";
?> 
<div id="page-wrapper">
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Questions
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i>  <a href="<?php echo base_url() ?>users/dashboard">Dashboard</a>
                    </li>
                    <li class="active">
                        <i class="fa fa-table"></i> Question
                    </li>
                </ol>
            </div>
        </div>
        <div class="row">
            <?php echo validation_errors(); ?>
            <form name="frm_search" id="frm_search" method="post" action="<?php echo base_url(); ?>users/list_of_questions">
                <div class="col-lg-6">   
                    <div class="form-group">
                        <label>Select state</label>                        
                        <?php echo form_dropdown('state_id', $states, '0', 'id="state" class="form-control"'); ?>
                    </div>                                       
                </div> 
                <div class="col-lg-6">
                    <div class="form-group">
                            <label>Select Constituency</label>
                            <?php $constituencies['0'] = 'Please Select'; ?>
                            <?php echo form_dropdown('constituency_id', $constituencies, '0', 'id="constituency" class="form-control"'); ?>
                    </div> 
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label>Question</label>                        
                        <input type="text" class="form-control" name="question" id="question">                        
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label></label> 
                        <input type="submit" class="btn btn-default" name="submit" value="SEARCH">
                        <input type="reset" class="btn btn-default" name="reset" value="RESET">
                    </div>
                </div>  
            </form>    
        </div>  
        <hr>
        <div class="row">
            <div class="col-lg-6">                
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                            <tr>
                                <th><a href="<?php echo base_url(); ?>users/list_of_questions/<?= $page_num ?>/id/<?= $order ?>">ID</a></th>
                                <th><a href="<?php echo base_url(); ?>users/list_of_questions/<?= $page_num ?>/state_id/<?= $order ?>">state_id</a></th>
                                <th><a href="<?php echo base_url(); ?>users/list_of_questions/<?= $page_num ?>/constituency_id/<?= $order ?>">Constituency</a></th>
                                <th><a href="<?php echo base_url(); ?>users/list_of_questions/<?= $page_num ?>/question/<?= $order ?>">Question</a></th>                    
                            </tr>                        
                        </thead>
                        <tbody>
                            <?php
                            $i = 0;
                            if (count($questiondata) > 0) {
                                foreach ($questiondata as $val) {
                                    ?>
                                    <tr>
                                        <td><?= $val["id"]; ?></td>
                                        <td><?= $val['state_id'] ?></td>
                                        <td><?= $val['constituency_id'] ?></td>
                                        <td><?= $val['question'] ?></td>                            
                                    </tr>
                                <?php } ?>
                                <?php
                            } else {
                                ?>
                                <tr class="odd"><td colspan="9">No records with this search</td></tr>
                                <?php
                            }
                            ?>                                        
                        </tbody>
                    </table>
                    <center><?php echo $page_links; ?></center>
                    <br /><br />  
                </div>                                
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

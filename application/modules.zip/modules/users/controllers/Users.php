<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {
    var $template  = array();
    var $data      = array();
    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->model('users_model');
        $this->load->helper('url_helper');
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library("pagination");
    }
    
    public function layout() {
        // making temlate and send data to view.
        $this->template['header']   = $this->load->view('layout/header', $this->data, true);
        if (isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'admin') {  
            $this->template['left']   = $this->load->view('layout/admin_left', $this->data, true);
        }else{
            $this->template['left']   = $this->load->view('layout/left', $this->data, true);
        }        
        $this->template['middle'] = $this->load->view($this->middle, $this->data, true);
        $this->template['footer'] = $this->load->view('layout/footer', $this->data, true);
        $this->load->view('layout/index', $this->template);        
   }

    /**
     * login function.
     * 
     * @access public
     * @return void
     */
    public function login() {        
        // set validation rules
        $this->form_validation->set_rules('user_id', 'User login id', 'required|alpha_numeric');
        $this->form_validation->set_rules('password', 'Password', 'required');
        if ($this->form_validation->run() == false) {
            $this->middle = 'login'; 
            $this->layout();            
        } else {
            // set variables from the form
            $this->data = array(
                'user_id' => $this->input->post('user_id'),
                'password' => $this->input->post('password'),
            );
            if ($this->users_model->login($this->data)) {
                $user = $this->users_model->read_user_information($this->data['user_id']);
                // set session user datas
                $_SESSION['id'] = $user[0]->id;
                $_SESSION['user_id'] = $user[0]->user_id;
                $_SESSION['first_name'] = $user[0]->first_name;
                $_SESSION['last_name'] = $user[0]->last_name;
                $_SESSION['logged_in'] = true;
                $_SESSION['status'] = $user[0]->status;
                $_SESSION['user_type'] = $user[0]->user_type;
                $_SESSION['email_id'] = $user[0]->email_id;
                // user login ok
                redirect('../users/dashboard');
                $this->layout(); 
            } else {
                // login failed
                $this->data['error_message'] = 'Wrong username or password.';
                // send error to the view                
                $this->middle = 'login'; 
                $this->layout(); 
            }
        }
    }

    public function registration() {
        if (!empty($_POST)) {
            $this->data = array(
                'user_type' => $this->input->post('user_type'),
                'first_name' => $this->input->post('first_name'),
                'last_name' => $this->input->post('last_name'),
                'user_id' => $this->input->post('user_id'),
                'mobile' => $this->input->post('mobile'),
                'email_id' => $this->input->post('email_id'),
                'password' => $this->input->post('password'),
                'passconf' => $this->input->post('passconf'),
                'otp' => $this->input->post('otp')
            );
            $this->form_validation->set_data($this->data);
            $this->form_validation->set_rules('user_type', 'User Type', 'required');
            $this->form_validation->set_rules('first_name', 'first_name', 'required');
            $this->form_validation->set_rules('last_name', 'last_name', 'required');
            $this->form_validation->set_rules(
                    'user_id', 'User Login Id', 'required|min_length[3]|max_length[20]|is_unique[users.user_id]', array(
                'required' => 'You have not provided %s.',
                'is_unique' => 'This %s already exists.'
                    )
            );
            $this->form_validation->set_rules('mobile', 'mobile', 'required');
            $this->form_validation->set_rules('email_id', 'Email', 'required|valid_email|is_unique[users.email_id]');
            $this->form_validation->set_rules('password', 'Password', 'required');
            $this->form_validation->set_rules('passconf', 'Password Confirmation', 'required|matches[password]');
            $this->form_validation->set_rules('otp', 'otp', 'required');
        }
        if ($this->form_validation->run() == FALSE) {
            $this->data['title'] = "BJP";
            $this->data['heading'] = "Registration form";            
            $this->middle = 'registration'; 
            $this->layout();
        } else {
            $result = $this->users_model->insert_entry($this->data); // call the employee model
            if ($result == true) {
                $this->data = $_POST = array();
                $this->data['error_message'] = 'You had been register successfully. Please login with your user_id & password';
                $this->middle = 'login'; 
                $this->layout();
            } else {
                echo "Not Inserted";
            }
        }
    }

    public function resetpwd() {
        $this->middle = 'resetpwd'; 
        $this->layout();        
    }

    public function changepwd() {
        $this->checklogin();
        $this->middle = 'changepwd'; 
        $this->layout(); 
    }

    /**
     * logout function.
     * 
     * @access public
     * @return void
     */
    public function logout() {
        // create the data object        
        if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
            // remove session datas
            foreach ($_SESSION as $key => $value) {
                unset($_SESSION[$key]);
            }
            // user logout ok
            redirect('../users/login');
            $this->layout();              
        } else {
            // there user was not logged in, we cannot logged him out,
            // redirect him to site root
            redirect('../users/home');
            $this->layout(); 
        }
    }

    public function dashboard() {   
        $this->checklogin();
        $this->load->model('survey/survey_info_model');
        $this->data['user_type']=$_SESSION['user_type'];
        $this->data['survey_count']=$this->survey_info_model->user_survey_count($_SESSION['id']);
        if (isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'admin') {            
            $this->middle ='admin_dashboard';
        } else {            
            $this->middle ='dashboard';
        }
        $this->layout(); 
    }

    public function home() {        
        if (isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'admin') {
            $this->middle ='admin_home';
        } else {           
            $this->middle ='home';
        }        
        $this->layout(); 
    }

    public function add_question() {
        $this->checklogin();
        $this->load->model('survey_questions_model');
        if (!empty($_POST)) {
            $this->data = array(
                'state_id' => $this->input->post('state_id'),
                'constituency_id' => $this->input->post('constituency_id'),
                'question' => $this->input->post('question'),
                'created_by' => $_SESSION['id'],
                'modified_by' => $_SESSION['id'],
                'status' => $this->input->post('status'),
            );            
            $this->form_validation->set_data($this->data);
            $this->form_validation->set_rules('state_id', 'State', 'required');
            $this->form_validation->set_rules('constituency_id', 'constituency', 'required');
            $this->form_validation->set_rules('question', 'question', 'required');
        }
        if ($this->form_validation->run() == FALSE) {
            $this->data['title'] = "BJP";
            $this->data['heading'] = "Add new survey question";
            $this->load->model('state_model');
            $this->data['states'] = $this->state_model->get_states();
            $this->middle = 'add_question'; 
            $this->layout();
        } else {
            $result = $this->survey_questions_model->add_new_survey_question($this->data); // call the employee model
            if ($result == true) {
                $this->data = $_POST = array();
                $this->data['error_message'] = 'You had been new question successfully.';
                $this->middle = 'add_question'; 
                $this->layout();
            } else {
                echo "Not Inserted.Please try again";
            }
        }
    }

    function get_constituencies($state) {
        $this->load->model('constituency_model');
        header('Content-Type: application/x-json; charset=utf-8');
        echo(json_encode($this->constituency_model->get_constituencies($state)));
    }
    
    function checklogin(){
        if (!$this->session->userdata('logged_in')) {
            $this->middle = 'login'; 
            $this->layout(); 
        } 
    }
    
    public function list_of_questions($page_num=1,$sortfield='',$order='') {		
	$this->checklogin();		
        $this->load->model('survey_questions_model');
        $search_keywords_array = array();
        $search_orderby_array = array();
        $search_orderby_string = '';
        //pagination

        $page_number = $this->uri->segment(2);
        $config['base_url'] = base_url() . 'list_of_questions/';
        $config['uri_segment'] = 2;

        if (!empty($sortfield))
            $search_orderby_array[] = $sortfield . ' ' . $order;

        if ($this->input->post()) {
            $state_id = $this->input->post('state_id');
            $constituency_id = $this->input->post('constituency_id');
            $question = $this->input->post('question');            

            if ($state_id!='' && $state_id!='0') {
                $search_keywords_array['state_id'] = $state_id;
                $this->survey_questions_model->searchterm_handler('state_id', $state_id);
            } else {
                $this->session->unset_userdata('state_id');
            }
            if ($constituency_id!='' && $constituency_id!='0') {
                $search_keywords_array['constituency_id'] = $constituency_id;
                $this->survey_questions_model->searchterm_handler('constituency_id', $constituency_id);
            } else {
                $this->session->unset_userdata('constituency_id');
            }
            if (trim($question)!='') {
                $search_keywords_array['question'] = $question;
                $this->survey_questions_model->searchterm_handler('question', $question);
            } else {
                $this->session->unset_userdata('question');
            }
            

            $reset = $this->input->post('reset');
            if (!empty($reset)) {
                $this->session->unset_userdata('state_id');
                $this->session->unset_userdata('constituency_id');
                $this->session->unset_userdata('question');                
                $search_keywords_array = array();
                $this->layout(); 
                redirect('list_of_questions/');
            }
        } else {
            if ($this->session->userdata("state_id"))
                $search_keywords_array['state_id'] = $this->session->userdata("state_id");
            if ($this->session->userdata("constituency_id"))
                $search_keywords_array['constituency_id'] = $this->session->userdata("constituency_id");
            if ($this->session->userdata("question"))
                $search_keywords_array['question'] = $this->session->userdata("question");                        
        }
        $search_orderby_string = implode(",", $search_orderby_array);

        $config['per_page'] = 0;
        $config['num_links'] = 5;
        if (empty($page_number))
            $page_number = 1;
        $offset = ($page_number - 1) * $config['per_page'];

        $config['use_page_numbers'] = TRUE;

        $this->data["questiondata"] = $this->survey_questions_model->questionsdata($config['per_page'], $offset, $search_keywords_array, $search_orderby_string);

        $this->db->select('*')->from('survey_questions');
        $this->db->like($search_keywords_array);
        $query_result = $this->db->get();

        $config['total_rows'] = $query_result->num_rows();
        $this->pagination->cur_page = $offset;

        $this->pagination->initialize($config);
        $this->data['page_links'] = $this->pagination->create_links();
        $this->load->model('state_model');
        $this->data['states'] = $this->state_model->get_states(); 
        $this->middle ='list_of_questions';
        $this->layout();         
    }    
}

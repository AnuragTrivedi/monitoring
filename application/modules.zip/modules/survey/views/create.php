<script type="text/javascript">
    function statechange() {
        $("#constituency > option").remove();
        var state_id = $('#state').val();
        $.ajax({
            type: "POST",
            url: "<?php echo base_url() ?>users/get_constituencies/" + state_id,
            success: function (constituencies)
            {
                $.each(constituencies, function (id, constituency)
                {
                    var opt = $('<option />');
                    opt.val(id);
                    opt.text(constituency);
                    $('#constituency').append(opt);
                });
            }
        });
    }
    function constituencychange() {        
        var state_id = $('#state').val();
        var constituency_id = $('#constituency').val();        
        $.ajax({
            type: "POST",
            async: false,
            url: "<?php echo base_url() ?>survey/get_survey_questions/" + state_id + "/" + constituency_id ,
            success: function (questions)
            {
                var sno=0;
                $.each(questions, function (id, question)
                {                                                          
                    $('#questions').append("<div class='form-group'><label>" + question + "</label><select name='" + id + "'><option value='1'>Yes</option><option value='0'>no</option></select>");                                                             
                    sno = eval(sno) + 1
                });  
                $("#questions_count").val(sno);                             
            }            
        });
    }        
</script>
<div id="page-wrapper">
    <div class="container-fluid">
        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Survey From                            
                </h1>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i><a href="index.html">Dashboard</a>
                    </li>
                    <li class="active">
                        <i class="fa fa-file"></i> Survey
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <?php
                if (isset($error_message)) {
                    echo $error_message;
                } else {
                    echo validation_errors();
                }
            ?> 
            <form method="POST" action="<?php echo base_url();?>survey/create">
                <input type="hidden" name="questions_count" id="questions_count">
                <div class="col-lg-6">   
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" class="form-control" name="first_name">
                        <p class="help-block">Example block-level help text here.</p>
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" class="form-control" name="last_name">
                        <p class="help-block">Example block-level help text here.</p>
                    </div>
                    <div class="form-group">
                        <label>Mobile No</label>
                        <input type="text" class="form-control" placeholder="Enter text" name="mobile_no">
                        <p class="help-block">Please enter your 10 digit mobile number</p>
                    </div>
                    <div class="form-group">
                        <label>Email-Id</label>
                        <input type="text" class="form-control" placeholder="Enter text" name="email_id">
                        <p class="help-block">Please enter your email-id</p>
                    </div>
                    <div class="form-group">
                        <label>Vote Id card / Adhar card</label>
                        <input type="text" class="form-control" name="voter_id">                                
                    </div>   
                    <div class="form-group">
                        <label>Reference No 1</label>
                        <input type="text" class="form-control" placeholder="Enter text" name="reference_no1">
                        <p class="help-block">Please enter Reference No</p>
                    </div>
                    <div class="form-group">
                        <label>Reference No 2</label>
                        <input type="text" class="form-control" name="reference_no1"> 
                        <p class="help-block">Please enter Reference No</p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <label>Select state</label>
                        <?php echo form_dropdown('state_id', $states, '#', 'id="state" class="form-control" onchange=statechange()'); ?>
                        <p class="help-block">Example block-level help text here.</p>
                    </div>
                    <div class="form-group">
                        <label>Select Constituency</label>
                        <?php $constituencies['#'] = 'Please Select'; ?>
                        <?php echo form_dropdown('constituency_id', $constituencies, '#', 'id="constituency" class="form-control" onchange="constituencychange()"'); ?>
                        <p class="help-block">Example block-level help text here.</p>
                    </div>                                       
                    <h4>Please select state & constituency to get related survey questions</h4>                            
                    <div id="questions">
                    </div>                       
                    <input type="submit" class="btn btn-default" name="submit" value="Submit"> 
                    <input type="reset" class="btn btn-default" name="submit" value="Reset"> 
                </div>
            </form>    
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
</div>
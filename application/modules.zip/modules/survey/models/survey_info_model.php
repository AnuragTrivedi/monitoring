<?php

class Survey_Info_model  extends CI_Model {
   
    public $id;
    public $user_id;
    public $first_name;
    public $last_name;
    public $mobile_no;
    public $voter_id;

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
    }

    public function add_new_survey_info($data) { 
        $this->user_id = $data['user_id'];
        $this->first_name = $this->input->post('first_name');
        $this->last_name = $this->input->post('last_name');
        $this->mobile_no = $this->input->post('mobile_no');
        $this->voter_id = $this->input->post('voter_id');        
        $this->db->insert('survey_info', $this);           
        if ($this->db->affected_rows() > 0) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }   
    
    public function user_survey_count($user_id) { 
        $condition = "user_id =" . "'" . $user_id . "'";
        $this->db->select('*');
        $this->db->from('survey_info');
        $this->db->where($condition);
        $this->db->limit(1);
        $query = $this->db->get();        
        return $query->num_rows();        
    }
}
?>
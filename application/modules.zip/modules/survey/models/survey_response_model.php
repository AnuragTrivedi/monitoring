<?php

class Survey_Response_model  extends CI_Model {
   
    public $id;
    public $survey_id;    
    public $question_id;
    public $response;  

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
    }

    public function add_new_survey_info($id,$question_id,$response) { 
        $this->survey_id = $id;
        $this->question_id = $question_id;
        $this->response = $response;                
        $this->db->insert('survey_response', $this);
        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }       
}

?>
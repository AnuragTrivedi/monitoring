<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Survey extends CI_Controller {
    
    var $template  = array();
    var $data      = array();
    
    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->model('survey_info_model');
        $this->load->model('survey_response_model');
        $this->load->model('users/survey_questions_model');
        $this->load->model('users/state_model');
        $this->load->helper('url_helper');
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->library('session');        
    }
    
    public function layout() {
        // making temlate and send data to view.
        $this->template['header']   = $this->load->view('layout/header', $this->data, true);
        if (isset($_SESSION['user_type']) && $_SESSION['user_type'] == 'admin') {  
            $this->template['left']   = $this->load->view('layout/admin_left', $this->data, true);
        }else{
            $this->template['left']   = $this->load->view('layout/left', $this->data, true);
        }        
        $this->template['middle'] = $this->load->view($this->middle, $this->data, true);
        $this->template['footer'] = $this->load->view('layout/footer', $this->data, true);
        $this->load->view('layout/index', $this->template);        
   }
   
    public function create() { 
        $this->checklogin();
        if (!empty($_POST)) {                
            $this->data = array(
                'user_id' => $_SESSION['id'],
                'first_name' => $this->input->post('first_name'),
                'last_name' => $this->input->post('last_name'),
                'mobile_no' => $this->input->post('mobile_no'),
                'voter_id' => $this->input->post('voter_id'), 
                'questions_count'=>$this->input->post('questions_count')
            );            
            $this->form_validation->set_data($this->data);
            $this->form_validation->set_rules('first_name', 'first name', 'required');
            $this->form_validation->set_rules('mobile_no', 'mobile no', 'required');                       
        }             
        if ($this->form_validation->run() == FALSE) {
            $this->data['page_title'] = 'Create new survey';            
            $this->data['states'] = $this->state_model->get_states();
            $this->middle = 'create'; 
            $this->layout();            
        } else {                   
            $last_inserted_id = $this->survey_info_model->add_new_survey_info($this->data);            
            if ($last_inserted_id != false && $last_inserted_id>0) {        
                $questionData=$this->survey_questions_model->get_survey_questions($this->input->post('state_id'),$this->input->post('constituency_id'));
                $i=1;
                foreach($questionData as $key => $value)
                {
                    $this->survey_response_model->add_new_survey_info($last_inserted_id,$key,$this->input->post($i));
                    $i++;
                }
                $this->data = $_POST = array();
                $this->data['error_message'] = 'You had been new question successfully.';
                $this->middle = 'users/dashboard'; 
                $this->layout();
            } else {
                echo "Not Inserted.Please try again";
            }
        }
    }    
    
    public function get_survey_questions($state_id,$constituency_id){
        header('Content-Type: application/x-json; charset=utf-8');
        echo(json_encode($this->survey_questions_model->get_survey_questions($state_id,$constituency_id)));
    }
    
    function checklogin(){
        if (!$this->session->userdata('logged_in')) {
            $this->middle = 'users/login'; 
            $this->layout(); 
        } 
    }
    
}

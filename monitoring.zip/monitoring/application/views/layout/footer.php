 <!-- jQuery -->
    <script src="<?php echo base_url() ?>js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url() ?>js/bootstrap.min.js"></script>
    </div>
</body>

</html>